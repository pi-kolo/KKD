Piotr Kołodziejczyk
244750

Program dynamic_huff.py realizuje dynamiczne kodowanie Huffmana pliku.
Uruchomienie:
python dynamic_huff.py -d/-e plik_wejściowy plik_wyjściowy,
gdzie -d albo -e znaczy odpowiednio dekodowanie/kodowanie

Uwagi:
- zgodnie ze specyfikacją działa dla ascii
- program koduje, nie kompresuje - zwracany jest ciąg zero-jedynkowy będący kodem, a nie plik binarny reprezentujący ów kod